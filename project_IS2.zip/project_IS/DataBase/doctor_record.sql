SELECT * FROM doctor_record;
