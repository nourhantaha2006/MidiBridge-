SELECT * FROM patient_record;
